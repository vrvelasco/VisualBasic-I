﻿Public Class Form1
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim strGrade As String
        strGrade = txtGrade.Text

        If strGrade = String.Empty Then
            MessageBox.Show("Please enter a grade")
        ElseIf Not IsNumeric(strGrade) Then
            MessageBox.Show("Please enter a numeric grade")
        ElseIf strGrade < 0 Or strGrade > 100 Then
            MessageBox.Show("Please enter a number between 0 and 100")
        Else
            lstGrades.Items.Add(strGrade)
            txtGrade.Clear()
            txtGrade.Focus()
        End If




    End Sub
End Class
