﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click, Me.Load
        'Declarations
        Const TAX_RATE As Double = 0.07

        Dim quantity As Integer
        Dim price As Double
        Dim subtotal, totalPrice, taxAmount As Double


        'Input quantity and price
        quantity = txtQuantity.Text
        price = txtPrice.Text

        subtotal = quantity * price
        taxAmount = subtotal * TAX_RATE
        totalPrice = subtotal + taxAmount

        'Calculate and display results
        lblOutput.Text = ("Subtotal: " & subtotal.ToString("C")) & ControlChars.CrLf
        lblOutput.Text = lblOutput.Text & ("Tax: " & taxAmount.ToString("C")) & ControlChars.CrLf
        lblOutput.Text = lblOutput.Text & ("Total price: " & totalPrice.ToString("C"))

    End Sub

    Private Sub txtQuantity_TextChanged(sender As Object, e As EventArgs) Handles txtQuantity.TextChanged
        lblOutput.Text = ""
    End Sub

End Class
