﻿Option Strict On

Public Class Form1

    Sub ErrMsg(errCode As Integer)
        If errCode = 1 Then
            MessageBox.Show("Enter a number greater than -50")
        ElseIf errCode = 2 Then
            MessageBox.Show("Enter a number less than 150")
        Else
            MessageBox.Show("An error has occurred. Please try again")
        End If
    End Sub

    Function FtoC(f As Integer) As Integer
        Dim c As Double
        c = 5 / 9 * (f - 32)
        Return CInt(c)
    End Function
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click

        Dim fahr As Integer
        Dim celsius As Double

        fahr = CInt(txtFahr.Text)

        If fahr <= -50 Then
            ErrMsg(1)
        ElseIf fahr > 150 Then
            ErrMsg(2)
        Else
            celsius = FtoC(fahr)
            lblOutput.Text = fahr & " F. is " & celsius.ToString("N") & " C."
        End If

    End Sub
End Class
